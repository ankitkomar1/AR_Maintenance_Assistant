import pandas as pd

def load_data(filepath):
    df = pd.read_csv(filepath)
    print("Dataset Preview:")
    print(df.head())

if __name__ == "__main__":
    load_data("dataset/maintenance_data.csv")
